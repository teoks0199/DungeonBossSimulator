using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Upgrade
{
    public void upgrade();
}
